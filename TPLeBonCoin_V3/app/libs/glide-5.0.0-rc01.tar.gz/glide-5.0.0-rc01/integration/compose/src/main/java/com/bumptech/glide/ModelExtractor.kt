package com.bumptech.glide

internal val RequestBuilder<*>.internalModel
  get() = model